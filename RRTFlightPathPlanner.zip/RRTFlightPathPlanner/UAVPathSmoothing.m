function [smoothWaypointsObj] = UAVPathSmoothing(ss,sv,pthObj)

nonSmoothWaypoints=pthObj.States(:,1:4);
counter=1;
optimizedWaypoints(counter,:)=nonSmoothWaypoints(1,:);
startNode=1;
endNode=startNode+1;
counter=counter+1;
lastNonCollisionNode=endNode;
while(endNode<=length(nonSmoothWaypoints))
    MotionValid=isMotionValid(sv,nonSmoothWaypoints(startNode,:),nonSmoothWaypoints(endNode,:));
    collide=~MotionValid;
    if(~collide)
        optimizedWaypoints(counter,:)=nonSmoothWaypoints(endNode,:);
        lastNonCollisionNode=endNode;
        endNode=endNode+1;
    end
    if(collide)
        optimizedWaypoints(counter,:)=nonSmoothWaypoints(lastNonCollisionNode,:);
        counter=counter+1;
        startNode=lastNonCollisionNode;
        endNode=startNode+1;
    end
end
%define an empty navPath Object.
smoothWaypointsObj=navPath(ss);
%add smooth waypoints to the object.
append(smoothWaypointsObj, optimizedWaypoints(:,1:4));

end

